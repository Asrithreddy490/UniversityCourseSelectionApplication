package entities;

  enum AdminStatus {
	 Applied,
	 Rejected,
	 Pending,
	 Confirmed;
	}

	 
	 
		
	


